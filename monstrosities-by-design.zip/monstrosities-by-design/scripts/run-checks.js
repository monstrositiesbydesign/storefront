const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const productsPath = path.join(root, 'public', 'products.json');
let ok = true;

if (!fs.existsSync(productsPath)) {
  console.error('ERROR: public/products.json not found.');
  process.exit(2);
}

const products = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
if (!Array.isArray(products)) {
  console.error('ERROR: products.json must contain an array.');
  process.exit(2);
}

products.forEach((p) => {
  if (!p.image) {
    console.warn(`WARN: product ${p.id} has no image field.`);
    ok = false;
    return;
  }
  const imgFile = p.image.replace(/^\//, '');
  const imgPath = path.join(root, imgFile);
  if (!fs.existsSync(imgPath)) {
    console.warn(`WARN: image file missing: ${imgPath} (product ${p.id})`);
    ok = false;
  }
});

if (!ok) {
  console.error('One or more checks failed.');
  process.exit(1);
}

console.log('All checks passed.');
process.exit(0);
