import React, { useEffect, useState } from 'react';
import { FaFacebook, FaInstagram, FaPinterest, FaTiktok, FaLink } from 'react-icons/fa';
import { Helmet } from 'react-helmet';

/* Basic helper */
const logoCandidates = ['/1000014671-removebg-preview.png', '/logo.png'];
const businessName = 'Monstrosities By Design';

function Logo({ className = 'h-12 w-auto' }) {
  const [idx, setIdx] = useState(0);
  const src = logoCandidates[idx];
  function handleError(e) {
    if (idx < logoCandidates.length - 1) {
      setIdx(i => i + 1);
      return;
    }
    e.currentTarget.onerror = null;
    e.currentTarget.src = '/images/placeholder.png';
  }
  return <img src={src} alt={businessName + ' logo'} className={className} onError={handleError} />;
}

function ProductCard({ p }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-2xl transition transform duration-200">
      <img src={p.image} alt={p.name} className="rounded-lg w-full h-52 object-cover mb-4 border border-gray-200" onError={(e)=>e.currentTarget.src='/images/placeholder.png'} />
      <h2 className="text-xl font-semibold mb-1">{p.name}</h2>
      <p className="text-sm text-indigo-600 font-medium mb-2">{p.category}</p>
      <p className="text-gray-600 mb-3 text-sm leading-relaxed">{p.description}</p>
      <p className="font-bold text-lg text-gray-900 mb-4">${Number(p.price).toFixed(2)}</p>
      <button className="bg-indigo-600 text-white px-5 py-2 rounded-lg shadow hover:bg-indigo-700 transition">Learn More</button>
    </div>
  );
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formStatus, setFormStatus] = useState(null);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('products') || 'null');
    if (stored && Array.isArray(stored) && stored.length) {
      setProducts(stored);
      setLoading(false);
      return;
    }
    fetch('/products.json')
      .then(r => (r.ok ? r.json() : []))
      .then(data => setProducts(Array.isArray(data) ? data : []))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  async function handleContact(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = { name: form.get('name'), email: form.get('email'), message: form.get('message') };
    try {
      const res = await fetch('https://formspree.io/f/movqyjnn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setFormStatus('Message sent — thanks!');
        e.currentTarget.reset();
      } else {
        setFormStatus('Sending failed — try again later.');
      }
    } catch {
      setFormStatus('Error sending message — check your connection.');
    }
  }

  return (
    <div className="min-h-screen flex flex-col justify-between bg-gradient-to-br from-gray-100 to-gray-200 p-6 font-sans">
      <Helmet>
        <title>{businessName} — Custom 3D Prints</title>
        <meta name="description" content={`${businessName} — BookTok bookmarks, home decor, aviation parts.`} />
      </Helmet>

      <header className="max-w-7xl mx-auto w-full mb-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Logo />
          <h1 className="text-2xl font-bold">{businessName}</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto w-full">
        {loading ? <p className="text-center">Loading...</p> :
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map(p => <ProductCard key={p.id} p={p} />)}
          </div>
        }

        <section className="mt-12 bg-white rounded-2xl shadow-md p-8 max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-4">Contact Us</h2>
          <form onSubmit={handleContact} className="space-y-4">
            <input name="name" type="text" placeholder="Your name" required className="w-full p-3 border rounded" />
            <input name="email" type="email" placeholder="Your email" required className="w-full p-3 border rounded" />
            <textarea name="message" rows="4" placeholder="Message" required className="w-full p-3 border rounded" />
            <div className="flex justify-center">
              <button type="submit" className="bg-indigo-600 text-white px-6 py-2 rounded-lg">Send Message</button>
            </div>
          </form>
          {formStatus && <p className="mt-3 text-center text-sm">{formStatus}</p>}
        </section>
      </main>

      <footer className="mt-12 py-6 border-t border-gray-300 flex flex-col items-center space-y-4">
        <p className="text-gray-700 font-medium">Follow us</p>
        <div className="flex space-x-6 text-2xl">
          <a href="https://www.facebook.com/profile.php?id=61562897134270" target="_blank" rel="noreferrer" className="text-blue-600 hover:scale-110 hover:shadow-lg hover:shadow-blue-400/50"><FaFacebook /></a>
          <a href="https://www.instagram.com/mnstrstsbydsgn/" target="_blank" rel="noreferrer" className="text-pink-500 hover:scale-110 hover:shadow-lg hover:shadow-pink-400/50"><FaInstagram /></a>
          <a href="https://www.pinterest.com/monstrositiesbydesign/" target="_blank" rel="noreferrer" className="text-red-600 hover:scale-110 hover:shadow-lg hover:shadow-red-400/50"><FaPinterest /></a>
          <a href="https://www.tiktok.com/@monstrosities.by" target="_blank" rel="noreferrer" className="text-black hover:scale-110 hover:shadow-lg hover:shadow-gray-500/50"><FaTiktok /></a>
          <a href="https://linktr.ee/MonstrositiesbyDesign" target="_blank" rel="noreferrer" className="text-green-600 hover:scale-110 hover:shadow-lg hover:shadow-green-400/50"><FaLink /></a>
        </div>
        <p className="text-gray-600">© {new Date().getFullYear()} Monstrosities By Design. All rights reserved.</p>
      </footer>
    </div>
  );
}
